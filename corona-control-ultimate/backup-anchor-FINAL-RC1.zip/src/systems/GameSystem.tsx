import React from 'react';
import { useFrame } from '@react-three/fiber';
import TimeSystem from './TimeSystem';

const GameSystem: React.FC = () => {
    useFrame((state, delta) => {
        // Core Systems Update Loop
        TimeSystem.update(delta);

        // Future Systems:
        // EventSystem.update(delta);
        // MissionSystem.update(delta);
        // CombatSystem.update(delta);
    });

    return null; // Logic only, no rendering
};

export default GameSystem;
