import { useRef, useMemo, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { RigidBody, CapsuleCollider, RapierRigidBody } from '@react-three/rapier';
import type { NPCData, NPCType } from '@/types/npc';
import { CivilianController, RioterController, PoliceController } from '@/systems/ai/Controllers';
import { AIController } from '@/systems/ai/AIController';
import * as THREE from 'three';
import { useGameStore } from '@/stores/gameStore';
// import AudioManager from '@/managers/AudioManager';
import CameraShakeSystem from '@/systems/CameraShake';
import type { CollisionEnterPayload } from '@react-three/rapier';
import { useParticleStore } from './Effects/ParticleSystem';

interface NPCProps {
    id: number;
    type?: string;
    state?: string;
    position?: [number, number, number];
}

const NPC: React.FC<NPCProps> = ({ id, type = 'TOURIST', state = 'IDLE', position }) => {
    // Refs
    const bodyRef = useRef<RapierRigidBody>(null);
    const meshRef = useRef<THREE.Group>(null);
    const controllerRef = useRef<AIController | null>(null);
    
    // Game Store
    const addPoints = useGameStore(state => state.addPoints);
    const updateMissionProgress = useGameStore(state => state.updateMissionProgress);
    const playerPos = useGameStore(state => state.player.position); 
    const spawnExplosion = useParticleStore(state => state.spawnExplosion);
    const markedNpcIds = useGameStore(state => state.markedNpcIds);

    // Initial Data
    const initialData = useMemo<NPCData>(() => {
        return {
            id: id,
            position: position || [(Math.random() - 0.5) * 60, 1, (Math.random() - 0.5) * 60], 
            velocity: [0, 0, 0],
            rotation: Math.random() * Math.PI * 2,
            state: state as any,
            type: type as NPCType,
        };
    }, [id, type, state, position]);

    const dataRef = useRef<NPCData>(initialData);

    // Synchronisation bei Teleport oder Typ-Änderung durch den Store
    useEffect(() => {
        if (position) {
            dataRef.current.position = position;
            if (bodyRef.current) {
                bodyRef.current.setTranslation({ x: position[0], y: position[1], z: position[2] }, true);
            }
        }
        if (type) {
            dataRef.current.type = type as NPCType;
        }
        if (state) {
            dataRef.current.state = state as any;
        }
    }, [position, type, state]);

    // Initialisiere Controller (Lazy, da dataRef populated sein muss)
    if (!controllerRef.current && dataRef.current) {
        if (dataRef.current.type === 'RIOTER') {
            controllerRef.current = new RioterController(dataRef.current);
        } else if (dataRef.current.type === 'POLICE') {
             controllerRef.current = new PoliceController(dataRef.current);
        } else {
             controllerRef.current = new CivilianController(dataRef.current);
        }
    }

    useFrame((state, delta) => {
        const data = dataRef.current;
        
        // LOD-System: Berechne Distanz zum Spieler
        const dx = playerPos[0] - data.position[0];
        const dz = playerPos[2] - data.position[2];
        const distanceToPlayerSq = dx * dx + dz * dz;
        
        // 5-Level LOD System (Distances Squared for performance)
        // Level 0: < 15m (225) - Full AI, Full Animation
        // Level 1: < 30m (900) - Simple AI, Skeleton Animation
        // Level 2: < 50m (2500) - No AI, No Animation (Physics only)
        // Level 3/4: Handled by InstancedCrowd (> 50m)
        
        // Optimierung: Math.sqrt ist teuer, vergleiche Quadrate
        
        const isLOD0 = distanceToPlayerSq < 225; // 15m
        const isLOD1 = distanceToPlayerSq < 900; // 30m
        
        // AI Update Rate
        // LOD 0: Jeder Frame
        // LOD 1: Jeder 3. Frame (Random offset to distribute load)
        // LOD 2: Kein AI Update (nur Physics Position Sync)
        
        let shouldUpdateAI = isLOD0;
        if (!isLOD0 && isLOD1) {
             shouldUpdateAI = Math.random() < 0.3; // ~20fps effektive AI
        }

        if (shouldUpdateAI) {
            // AI nur bei nahen NPCs oder sporadisch bei fernen
            if (isLOD0 || Math.random() < delta * 2) { // isLOD0 is equivalent to isNearPlayer for AI update
                if (controllerRef.current) {
                    controllerRef.current.update(delta, playerPos);
                    dataRef.current = controllerRef.current.getData(); // Sync back
                }
            }
             // Sync Rotation nur wenn AI lief
            if (bodyRef.current) {
                bodyRef.current.setRotation(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), dataRef.current.rotation), true);
            }
        }

        if (bodyRef.current) {
            // Physics Sync immer nötig solange gerendert, sonst gleiten sie
            const currentPos = bodyRef.current.translation();
            // Nur Y syncen wenn wir fallen/springen, X/Z kommt von Physics ODER AI? 
            // Rapier ist "sovereign" für Position, AI setzt Velocity (impulse).
            // Hier nutzen wir kinematicPosition, also setzen wir die Position manuell.
            // Das ist okay für LOD0/1.
            
            bodyRef.current.setTranslation({ 
                x: dataRef.current.position[0], 
                y: currentPos.y, 
                z: dataRef.current.position[2] 
            }, true);
        }

        // Animation
        if (meshRef.current) {
            if (isLOD1) { // Animation bis 30m
                const nextState = dataRef.current.state;
                if (nextState === 'WALK' || nextState === 'PANIC' || nextState === 'CHASE' || nextState === 'ATTACK') {
                     // Einfache Wackel-Animation
                    meshRef.current.rotation.z = Math.sin(state.clock.elapsedTime * 15) * 0.05;
                    // TODO: Hier echte Skeleton Animation triggern wenn verfügbar
                } else {
                    meshRef.current.rotation.z = 0;
                }
            }
        }
    });

    const handleCollision = (e: CollisionEnterPayload) => {
        if (e.other.rigidBodyObject?.name === 'projectile') {
             // AudioManager.getInstance().playHitSound();
             spawnExplosion(dataRef.current.position, dataRef.current.type === 'RIOTER' ? 'red' : 'orange', 15);
             
             // Camera-Shake bei Treffer für viszerales Feedback
             CameraShakeSystem.getInstance().hitShake();
             
             if (dataRef.current.type === 'RIOTER') {
                 addPoints(50);
                 updateMissionProgress(1);
                 dataRef.current.state = 'PANIC';
                 dataRef.current.type = 'CIVILIAN'; 
             } else {
                 addPoints(-10);
                 dataRef.current.state = 'PANIC';
             }
        }
    };

    const getColor = (npcType: NPCType | 'KRAUSE', state: string) => {
        if (npcType === 'POLICE') return '#002266'; 
        if (npcType === 'RIOTER') return state === 'ATTACK' ? '#D32F2F' : '#8E0000'; 
        if (npcType === 'KRAUSE') return '#4e342e'; // Unauffälliges Braun
        if (state === 'PANIC') return '#FF9800';
        return '#7CB342'; 
    };

    return (
        <RigidBody 
            ref={bodyRef} 
            type="kinematicPosition" 
            position={initialData.position} 
            colliders={false}
            onCollisionEnter={handleCollision}
            userData={{ type: 'npc', id: id, faction: dataRef.current.type }} 
        >
            <CapsuleCollider args={[0.5, 0.3]} />
            <group ref={meshRef}>
                 <mesh castShadow receiveShadow>
                    <capsuleGeometry args={[0.3, 1.4, 4, 8]} />
                    {dataRef.current.type === 'POLICE' ? (
                        <meshStandardMaterial color={getColor(dataRef.current.type, dataRef.current.state)} metalness={0.6} roughness={0.2} />
                    ) : (
                        <meshStandardMaterial color={getColor(dataRef.current.type, dataRef.current.state)} />
                    )}
                    
                    <mesh position={[0, 0.5, 0.25]}>
                        <boxGeometry args={[0.4, 0.15, 0.2]} />
                        <meshStandardMaterial color={dataRef.current.type === 'POLICE' ? 'black' : 'white'} />
                    </mesh>
                    
                    {dataRef.current.type === 'POLICE' && (
                        <mesh position={[0, 0.8, 0]}>
                            <boxGeometry args={[0.2, 0.2, 0.2]} />
                             <meshStandardMaterial color="#333" />
                        </mesh>
                    )}
                 </mesh>
                 {/* ID-Marker für identifizierte NPCs */}
                 {markedNpcIds.includes(id) && (
                    <group position={[0, 2.2, 0]}>
                         <mesh>
                            <sphereGeometry args={[0.15, 16, 16]} />
                            <meshStandardMaterial color="red" emissive="red" emissiveIntensity={2} />
                         </mesh>
                         <pointLight color="red" intensity={0.5} distance={2} />
                    </group>
                 )}
            </group>
        </RigidBody>
    );
};

export default NPC;
