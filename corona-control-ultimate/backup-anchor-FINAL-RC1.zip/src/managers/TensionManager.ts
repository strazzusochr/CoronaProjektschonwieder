import { useGameStore } from '@/stores/gameStore';
import GameEventSystem from '@/systems/GameEventSystem';
import type { StimulusType } from '@/types/ai';

class TensionManager {
    private static instance: TensionManager;
    private readonly DECAY_RATE = 0.5; // Points per second
    private readonly WAVE_THRESHOLD = 30; // Tension needed to start spawning waves
    private lastWaveTime = 0;

    private constructor() {}

    public static getInstance(): TensionManager {
        if (!TensionManager.instance) {
            TensionManager.instance = new TensionManager();
        }
        return TensionManager.instance;
    }

    public update(delta: number, currentTime: number) {
        const store = useGameStore.getState();
        const currentTension = store.tensionLevel;

        // 1. Process recent events to increase tension
        const recentEvents = GameEventSystem.getInstance().getActiveStimuli(currentTime);
        let tensionIncrease = 0;

        // Helper to avoid double counting limits effectiveness, but simple for now
        // A better approach would be consuming events, but GameEventSystem keeps them for AI perception
        // We will just assume events add tension only if they are "fresh" (handled via EventSystem logic ideally)
        // For now, let's just add passive background tension if there are MANY active stimuli (Chaos)
        if (recentEvents.length > 5) {
            tensionIncrease += delta * 2; // Chaos factor
        }

        // 2. Decay Tension (Calm down if nothing happens)
        let newTension = currentTension + tensionIncrease - (this.DECAY_RATE * delta);

        // 3. Spawning Waves Logic
        // If tension is high, spawn sleeper cells occasionally
        if (newTension > this.WAVE_THRESHOLD) {
            if (currentTime - this.lastWaveTime > 10000) { // Every 10s check
                 if (Math.random() < (newTension / 100) * 0.5) { // Higher tension = Higher chance
                     // Spawn a small wave
                     console.log("Tension Surge! Spawning Wave.");
                     store.spawnWave(2 + Math.floor(newTension / 20), 'RIOTER');
                     store.setPrompt("ACHTUNG: Verstärkung trifft ein!");
                     this.lastWaveTime = currentTime;
                 }
            }
        }

        // Clamp
        newTension = Math.max(0, Math.min(100, newTension));
        
        // Update Store only if changed significantly to avoid spam
        if (Math.abs(newTension - currentTension) > 0.1) {
            store.setTension(newTension);
        }
    }
    
    // Call this when major events happen (Explosion, Player Kill)
    public triggerEvent(_type: StimulusType, value: number = 5) {
         const store = useGameStore.getState();
         store.setTension(store.tensionLevel + value);
    }
}

export default TensionManager;
