import { describe, it, expect, beforeEach, vi } from 'vitest';
import { checkQuestTriggers, startQuest, completeObjective, SIDE_QUESTS } from '../QuestManager';
import { useGameStore } from '@/stores/gameStore';

// Mock Store
vi.mock('@/stores/gameStore', () => ({
    useGameStore: {
        getState: vi.fn(() => ({
            setPrompt: vi.fn(),
            addPoints: vi.fn(),
            setTension: vi.fn(),
            tensionLevel: 50
        }))
    }
}));

describe('QuestManager', () => {
    beforeEach(() => {
        // Reset Quest States
        SIDE_QUESTS.forEach(q => {
            q.status = 'LOCKED';
            q.objectives.forEach(o => o.completed = false);
        });
    });

    it('should unlock quests based on time', () => {
        const quest = SIDE_QUESTS[0]; // SQ_VERLORENER_SOHN (30 min = 1800000ms)
        const triggerTime = quest.triggerTime;

        checkQuestTriggers(triggerTime - 100);
        expect(quest.status).toBe('LOCKED');

        checkQuestTriggers(triggerTime + 100);
        expect(quest.status).toBe('AVAILABLE');
    });

    it('should start a quest', () => {
        const quest = SIDE_QUESTS[0];
        quest.status = 'AVAILABLE';

        const started = startQuest(quest.id);
        expect(started).toBe(true);
        expect(quest.status).toBe('ACTIVE');
    });

    it('should complete objectives and finish quest', () => {
        const quest = SIDE_QUESTS[0];
        quest.status = 'ACTIVE';

        // Complete Obj 1
        completeObjective(quest.id, quest.objectives[0].id);
        expect(quest.objectives[0].completed).toBe(true);
        expect(quest.status).toBe('ACTIVE');

        // Complete All
        quest.objectives.forEach(o => completeObjective(quest.id, o.id));
        expect(quest.status).toBe('COMPLETED');
    });
});
